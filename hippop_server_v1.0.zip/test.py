from config import *

runInput("Enter your name:" )