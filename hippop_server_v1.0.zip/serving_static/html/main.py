#This enviroment is meant for only websites, webapps, 
#development only

import sys
import os
from hpWebFrame import(Flask, render_template)
from config import *

console("Starting Service\n")

console("preparing JS package\n")
console("running JS......\n")
console("Loading Web Database......\n")
console("running IP http://127.0.0.1 at port 8000")
console("Your Server is ready!")
app = Flask(__name__)
console("server is currently running")

@app.route("/")
def index(self=None):
#to create more links copy this code
#@app.route("/")
#def index(self=None):
#and just change the name from index to anyone of your
#choice and also add a file path


	#self test
	consoleRun = "return"
	return render_template("index.html")#add your file path here


























#Do not adit this part of the configuration file
#returning to the default headers
if __name__ == "__main__":
	app.config['DEBUG']=True
#cofiguration for the hip pop server

	host = ["127.0.0.1", "5000", "True"]
	hostURL = host[0]
	hostPORT = host[1]
	hostDEBUGGER = host[2]
	app.run(hostURL, hostPORT)
	
