import sys
import os

import debug

#import a debugger from git hub

def stateRun():
	x = 1
	if x:
		return x


def runCode():
	cprint = print()


def runStation():
	runCode()

runStation()
	