import os 
import sys



#module configuration process
run = [print]
eachin = ["each"]
makeDir = [os.mkdir]
runInput = [input]
first_Try = ["try"]


#use console to run your code
console = run[0]
runInput = runInput[0]
makeDir = makeDir[0]
first_Try = first_Try[0]



console
runInput
makeDir
first_Try


#automated generated greeting once you run this
