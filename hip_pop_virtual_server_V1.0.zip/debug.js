function debug(x){
	//this is a debugger code
	debug = state[ON]
	debug = []

}
debug(x)