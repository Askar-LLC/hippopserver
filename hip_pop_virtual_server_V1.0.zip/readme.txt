Hip pop virtual server v1.0
follow this simple step:
1. Extract Hippop Server v1.0.zip file
2. Add the extracted file to the C path in your hard drive
3. Run CMD 
4. Run the copy the HPVS/__init__.py path to the CMD and enjoy

Note: if you feel there is more to add to this open source software or any bug found let me know
email: geckosearch2018@gmail.com