from distutils import *
import os
import sys
from config import *

setupStart = {
"name": "HPVS", 
"version": "1.0.0", 
"description": "A light weight virtual server", 
"developer": "Askar-LLC"}