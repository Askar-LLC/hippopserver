to import any module use web_packages for example
from web_packages.hpWebFrame

All thanks to the team 
1. Bs4
2. Flask
3. Postgres

More will be added........
